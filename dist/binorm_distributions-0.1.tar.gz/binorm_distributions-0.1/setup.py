from setuptools import setup

setup(name='binorm_distributions',
      version='0.1',
      description='Binomial and Gaussian distributions',
      packages=['binorm_distributions'],
      zip_safe=False)
